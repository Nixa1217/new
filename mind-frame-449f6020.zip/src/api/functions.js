import { base44 } from './base44Client';


export const WhopWebhook = base44.functions.WhopWebhook;

